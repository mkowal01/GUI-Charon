namespace RPiRgbLEDMatrix;

/// <summary>
/// Scan modes.
/// </summary>
public enum ScanModes
{
    Progressive = 0,
    Interlaced = 1
}
